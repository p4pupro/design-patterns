package codigo_telescopio_clase;

public interface LocalizadorMesonesio {
    public void ubicarPlanares();
    public void ubicarGranulos();
    public void ubicarSemicuantos();
}
