package codigo_telescopio_clase;

public class LocalizadorAcutal {
	
	public LocalizadorAcutal() {

	}
	
	public void ajustarAlfas () 
	{ 
		System.out.println("Localizdor Acutal: Ajuste de los parámetros alfa");
		
	}
	
	public void ajustarGammas()
	{
		 System.out.println("Localizador Actual: Ajuste de los parámetros gamma");
		 
	}
	
	
	
}