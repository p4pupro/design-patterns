package trajeEspacial;

public class VideoVigilancia {

	public VideoVigilancia() {
		
		System.out.println("El traje dispone de video vigilancia");
		
	}
	
	
	public void activar() {
		
		System.out.println("Se activa videovigilancia");
		
	}
	
	public void desactivar() {
		
		System.out.println("Se desactiva videovigilancia");
		
	}	
}
