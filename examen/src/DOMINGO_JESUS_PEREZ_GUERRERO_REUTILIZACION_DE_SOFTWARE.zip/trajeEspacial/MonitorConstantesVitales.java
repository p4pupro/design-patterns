package trajeEspacial;

public class MonitorConstantesVitales {

	public MonitorConstantesVitales() {
		
		System.out.println("Creación de monitor de constantes vitales.");
		
	}
	
	
	public void iniciar() {
		
		System.out.println("Se inicia la monitorización de las constantes del astronauta");
		
	}
	
	public void pausar() {
		
		System.out.println("Se interrumpe la monitorización de las constantes del astronauta");
		
	}	
}
