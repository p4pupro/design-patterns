package trajeEspacial;

public interface Orden {
	
	public void ejecutar();

}
